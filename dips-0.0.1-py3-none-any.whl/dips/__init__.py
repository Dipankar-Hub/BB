def sumtwo(a,b):
    print("sumtwo is executing")
    return a+b